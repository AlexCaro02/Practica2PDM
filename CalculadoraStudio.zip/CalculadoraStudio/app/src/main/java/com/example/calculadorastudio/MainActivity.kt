package com.example.calculadorastudio

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.TextView

class MainActivity : AppCompatActivity() {

    //Creamos la variable
    var resultadoTextView: TextView?=null;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        //Vinculamos la variable
        resultadoTextView=findViewById(R.id.resultadoTextView)
    }

    fun calcular(view : View){
        //creo una variable botón, y le asigno el contenido del string
        var boton=view as Button
        var textoBoton=boton.text.toString()
        //creo una variable que va a ir concatenando el texto del botón con el texto que ya tiene "resultadoTextView"
        var concatenar=resultadoTextView?.text.toString()+textoBoton
        var concatenarSinCeros=quitarCerosIzquirda(concatenar)
        if(textoBoton=="="){
            var resultado=0.0
            try {
                //evaluo la operación matematica que está dentro de resultado
                resultado=eval(resultadoTextView?.text.toString())
                resultadoTextView?.text=resultado.toString()
            }catch (e:Exception){ //si hay algún error de cálculo (5++*)
                resultadoTextView?.text="Syntax Error"
            }
        }else if(textoBoton=="CL"){ //si limpiamos pantalla
            resultadoTextView?.text="0" //ponemos como resultado un 0
        }else if(textoBoton=="BACK"){ //si deshacemos acción
            val length = resultadoTextView!!.length()
            if(length > 0)
                resultadoTextView!!.text = resultadoTextView!!.text.subSequence(0, length - 1)
        } else{
            resultadoTextView?.text=concatenarSinCeros //si no pulsamos el reset niel igual, mostramos lo que haya sin ceros
        }
    }

    //funcion que quita los 0 a la izquierda de los numeros, para que no salga "08" en el resultado

    fun quitarCerosIzquirda(str : String):String{
        var i=0

        while (i<str.length && str[i]=='0')i++ //con esto calculo cuantos 0 a la izq hay

        //remplazo desde el principio hasta la letra i, con espacios en blanco
        val sb=StringBuffer(str)
        sb.replace(0,i,"")
        return sb.toString()
    }

    //funcion que realiza los calculos aritmeticológicos

    fun eval(str: String): Double {
        return object : Any() {
            var pos = -1
            var ch = 0
            fun nextChar() {
                ch = if (++pos < str.length) str[pos].toInt() else -1
            }

            fun eat(charToEat: Int): Boolean {
                while (ch == ' '.toInt()) nextChar()
                if (ch == charToEat) {
                    nextChar()
                    return true
                }
                return false
            }

            fun parse(): Double {
                nextChar()
                val x = parseExpression()
                if (pos < str.length) throw RuntimeException("Unexpected: " + ch.toChar())
                return x
            }

            fun parseExpression(): Double {
                var x = parseTerm()
                while (true) {
                    if (eat('+'.toInt())) x += parseTerm() // suma
                    else if (eat('-'.toInt())) x -= parseTerm() // resta
                    else return x
                }
            }

            fun parseTerm(): Double {
                var x = parseFactor()
                while (true) {
                    if (eat('*'.toInt())) x *= parseFactor() // multiplication
                    else if (eat('/'.toInt())) x /= parseFactor() // division
                    else return x
                }
            }

            fun parseFactor(): Double {
                if (eat('+'.toInt())) return parseFactor() // signo mas(numeros positivos)
                if (eat('-'.toInt())) return -parseFactor() // signo menos(numeros negativos)
                var x: Double
                val startPos = pos

                //Para el uso de los paréntesis

                if (eat('('.toInt())) {
                    x = parseExpression()
                    eat(')'.toInt())
                } else if (ch >= '0'.toInt() && ch <= '9'.toInt() || ch == '.'.toInt()) { // numeros
                    while (ch >= '0'.toInt() && ch <= '9'.toInt() || ch == '.'.toInt()) nextChar()
                    x = str.substring(startPos, pos).toDouble()
                } else {
                    throw RuntimeException("Unexpected: " + ch.toChar())
                }
                return x
            }
        }.parse()
    }


}

